﻿namespace SchooldataDb
{
    public class Class1
    {

    }
}