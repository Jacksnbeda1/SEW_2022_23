using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ggTWeb.Pages
{
   
}
    public class ggtcalculatorModel : PageModel
    {
        public string Result { get; set; }

        public void OnGet(double value, double value2)
        {
           
        }
    }

